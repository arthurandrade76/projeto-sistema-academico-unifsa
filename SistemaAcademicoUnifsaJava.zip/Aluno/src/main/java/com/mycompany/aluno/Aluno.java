
package com.mycompany.aluno;
public class Aluno {
    private String nome;
    private int matricula;
    private double nota;

    public Aluno(String nome, int matricula, double nota) {
        if (nome == null || nome.trim().isEmpty()) {
            this.nome = "Aluno Sem Nome";
        } else {
            this.nome = nome;
        }
        
        this.matricula = matricula;
        
        if (nota >= 0 && nota <= 10) {
            this.nota = nota;
        } else {
            this.nota = 0.0;
        }
    }

    public String getNome() {
        return nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        if (nota >= 0 && nota <= 10) {
            this.nota = nota;
        }
    }

    public void ajustarNota(double novaNota) {
        setNota(novaNota);
    }

    public void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Matrícula: " + matricula);
        System.out.println("Nota Final: " + nota);
    }
}

